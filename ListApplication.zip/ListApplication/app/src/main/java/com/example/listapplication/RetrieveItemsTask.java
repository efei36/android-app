package com.example.listapplication;

import android.os.AsyncTask;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

// This class retrieves data from the remote json file.
public class RetrieveItemsTask extends AsyncTask<Void, Void, List<DataItem>> {
    private static final String API_URL = "https://fetch-hiring.s3.amazonaws.com/hiring.json";
    private final OnTaskCompleted listener;

    public RetrieveItemsTask(OnTaskCompleted listener) {
        this.listener = listener;
    }

    @Override
    protected List<DataItem> doInBackground(Void... voids) {
        try {
            URL url = new URL(API_URL);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            InputStream inputStream = connection.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            StringBuilder result = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                result.append(line);
            }

            Type listType = new TypeToken<List<DataItem>>() {}.getType();
            return new Gson().fromJson(result.toString(), listType);
        } catch (IOException e) {
            Log.e("RetrieveItemsTask", "Error fetching data", e);
            return null;
        }
    }

    @Override
    protected void onPostExecute(List<DataItem> items) {
        super.onPostExecute(items);
        if (listener != null) {
            listener.onTaskCompleted(items);
        }
    }

    public interface OnTaskCompleted {
        void onTaskCompleted(List<DataItem> items);
    }
}