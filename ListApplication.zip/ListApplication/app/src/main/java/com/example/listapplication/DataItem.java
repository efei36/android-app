package com.example.listapplication;

public class DataItem {
    private int id;
    private int listId;
    private String name;

    // getters
    public int getId() {
        return id;
    }

    public int getListId() {
        return listId;
    }

    public String getName() {
        return name;
    }
}