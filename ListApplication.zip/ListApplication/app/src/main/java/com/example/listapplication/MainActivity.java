package com.example.listapplication;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.ArrayAdapter;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.Comparator;
import java.util.Collections;

public class MainActivity extends AppCompatActivity implements RetrieveItemsTask.OnTaskCompleted {

    private ArrayAdapter<String> adapter;
    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);
        listView.setAdapter(adapter);

        // Retrieve data from the remove json file
        new RetrieveItemsTask(this).execute();
    }

    @Override
    public void onTaskCompleted(List<DataItem> dataItems) {
        if (dataItems != null) {
            // Filter out any items where "name" is blank or null.
            List<DataItem> filteredDataItems = new ArrayList<>();
            for (DataItem item : dataItems) {
                if (item.getName() != null && !item.getName().isEmpty()) {
                    filteredDataItems.add(item);
                }
            }

            // Sort the results first by "listId" then by "name"
            Collections.sort(filteredDataItems, new Comparator<DataItem>() {
                @Override
                public int compare(DataItem o1, DataItem o2) {
                    int result = Integer.compare(o1.getListId(), o2.getListId());
                    if (result == 0) {
                        return o1.getName().compareTo(o2.getName());
                    }
                    return result;
                }
            });

            // Display all the items grouped by "listId"
            displayDataItems(filteredDataItems);
        }
    }

    //
    // This methods display all the items grouped by "listId"
    //
    private void displayDataItems(List<DataItem> items) {
        // Current listId, initialized to a value non-existing in the data file.
        int curListId = -100;

        for (DataItem item : items) {
            if (item.getListId() != curListId) {
                adapter.add("ListId " + item.getListId());
                curListId = item.getListId();
            }
            adapter.add("     Name: " + item.getName() + ", Id: " + item.getId());
        }
    }
}
